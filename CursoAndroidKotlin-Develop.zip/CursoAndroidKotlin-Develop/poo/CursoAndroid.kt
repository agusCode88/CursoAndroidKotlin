package poo

class CursoAndroid(nombreCurso:String,relator: Relator = Relator()) {

    var nombreCurso= nombreCurso
    var listaEstudiantes = mutableListOf<Estudiante>()

    constructor() : this ("",Relator())

    fun agregarEstudiante(estudiante: Estudiante){

        if(estudiante!= null){
            listaEstudiantes.add(estudiante)
            val mensajeria = Mensajeria(estudiante)
            mensajeria.mostrarMensajeAgregado()
            //println("Estudiante ${estudiante.nombreEstudiante} ha sido agregado")
        } else {
            val mensajeria = Mensajeria(estudiante)
            mensajeria.mostrarMensajeNoAgregado()
            //println("Estudiante ${estudiante
        }
    }

    fun listarEstudiantesCurso(){
        if(listaEstudiantes.isEmpty()){
            println("No hay estudiantes a mostrar")
        } else {
            for (estudiante in listaEstudiantes) {
                println("- Nombre: ${estudiante.nombreEstudiante}, RUT: ${estudiante.rutEstudiante}, Edad: ${estudiante.edad}")
            }

        }
    }

    fun eliminarEstudianteDelCurso (estudiante: Estudiante){
       // var estudianteEcontrado: Estudiante? = listaEstudiantes.find { it -> (it.nombreEstudiante == nombreEstudiante) }

        if(estudiante != null){
            listaEstudiantes.remove(estudiante)
            println("Estudiante ha sido eliminad@")
        } else {
            println("No ha sido eliminad@")
        }
    }
    fun modificarEstudiante(estudiante: Estudiante){
        var encontrado = listaEstudiantes.contains(estudiante)

        if(encontrado){
            println("Rut: ")
            var rut = readLine().toString()
            estudiante.rutEstudiante = rut
            println("Nombre: ")
            var nombreEstudiante = readLine().toString()
            estudiante.nombreEstudiante = nombreEstudiante
            println("Edad: ")
            var edad = readLine()?.toInt() ?: 0
            estudiante.edad = edad
            println("Fecha nacimiento: ")
            var fechaNacimiento =readLine().toString()
            estudiante.fechaNacimiento = fechaNacimiento
        }
    }


}