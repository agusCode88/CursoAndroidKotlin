package poo

class Relator(nombre:String ,sueldo:Int) {

    var nombre=nombre
    var sueldo = sueldo

    constructor() : this ("",0)
}